package com.example.cpc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CpcApplication {

	public static void main(String[] args) {
		SpringApplication.run(CpcApplication.class, args);
	}

}
