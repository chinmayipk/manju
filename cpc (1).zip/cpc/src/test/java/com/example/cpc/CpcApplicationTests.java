package com.example.cpc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CpcApplicationTests {

	@Test
	void contextLoads() {
	}

}
